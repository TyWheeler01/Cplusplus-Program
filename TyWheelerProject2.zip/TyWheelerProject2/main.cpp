#include <iostream>
#include <string>
#include "investment_calculator.h"

using namespace std;

int main() {
    cout << "Welcome to Airgead Banking Investment Calculator!" << endl;
    cout << "Please enter the following information to calculate your investment growth:" << endl;

    double initialInvestment, monthlyDeposit, annualInterestRate;
    int numberOfYears;

    // Loop to allow testing multiple scenarios
    while (true) {
        // Get user input
        cout << "Enter initial investment amount: ";
        cin >> initialInvestment;

        cout << "Enter monthly deposit amount: ";
        cin >> monthlyDeposit;

        cout << "Enter annual interest rate (%): ";
        cin >> annualInterestRate;

        cout << "Enter number of years: ";
        cin >> numberOfYears;

        // Create an instance of InvestmentCalculator with user input
        InvestmentCalculator calculator(initialInvestment, monthlyDeposit, annualInterestRate, numberOfYears);

        // Calculate and display investment growth
        calculator.calculateInvestmentGrowth();

        // Ask user if they want to test another scenario
        cout << "Do you want to test another scenario? (yes/no): ";
        string choice;
        cin >> choice;

        // If user chooses not to test another scenario, break out of the loop
        if (choice != "yes") {
            break;
        }
    }

    return 0;
}
