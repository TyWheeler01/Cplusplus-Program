#include "investment_calculator.h"
#include <iostream>
#include <iomanip>

InvestmentCalculator::InvestmentCalculator(double initialInvestment, double monthlyDeposit, double annualInterest, int years) {
    initialInvestmentAmount = initialInvestment;
    this->monthlyDeposit = monthlyDeposit;
    annualInterestRate = annualInterest;
    numberOfYears = years;
}

void InvestmentCalculator::setInitialInvestment(double initialInvestment) {
    initialInvestmentAmount = initialInvestment;
}

void InvestmentCalculator::setMonthlyDeposit(double monthlyDeposit) {
    this->monthlyDeposit = monthlyDeposit;
}

void InvestmentCalculator::setAnnualInterestRate(double annualInterestRate) {
    this->annualInterestRate = annualInterestRate;
}

void InvestmentCalculator::setNumberOfYears(int numberOfYears) {
    this->numberOfYears = numberOfYears;
}

double InvestmentCalculator::getInitialInvestment() {
    return initialInvestmentAmount;
}

double InvestmentCalculator::getMonthlyDeposit() {
    return monthlyDeposit;
}

double InvestmentCalculator::getAnnualInterestRate() {
    return annualInterestRate;
}

int InvestmentCalculator::getNumberOfYears() {
    return numberOfYears;
}

void InvestmentCalculator::calculateInvestmentGrowth() {
    double openingAmount = initialInvestmentAmount;
    double totalAmount = 0.0;

    std::cout << std::setw(5) << "Year" << std::setw(15) << "Opening Amount" << std::setw(15) << "Deposited Amount"
        << std::setw(10) << "Total" << std::setw(15) << "Interest" << std::setw(20) << "Closing Balance" << std::endl;

    for (int year = 1; year <= numberOfYears; ++year) {
        double interest = calculateCompoundInterest(openingAmount);
        double closingBalance = openingAmount + monthlyDeposit + interest;
        totalAmount += monthlyDeposit;

        std::cout << std::setw(5) << year << std::setw(15) << openingAmount << std::setw(15) << monthlyDeposit
            << std::setw(10) << totalAmount << std::setw(15) << interest << std::setw(20) << closingBalance << std::endl;

        openingAmount = closingBalance;
    }
}

double InvestmentCalculator::calculateCompoundInterest(double openingAmount) {
    double monthlyInterestRate = annualInterestRate / 100.0 / 12.0;
    return (openingAmount + monthlyDeposit) * monthlyInterestRate;
}
