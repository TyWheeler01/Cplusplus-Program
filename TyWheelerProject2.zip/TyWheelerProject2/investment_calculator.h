#pragma once
#ifndef INVESTMENT_CALCULATOR_H_
#define INVESTMENT_CALCULATOR_H_

class InvestmentCalculator {
private:
    double initialInvestmentAmount;
    double monthlyDeposit;
    double annualInterestRate;
    int numberOfYears;

public:
    InvestmentCalculator(double initialInvestment, double monthlyDeposit, double annualInterest, int years);
    void setInitialInvestment(double initialInvestment);
    void setMonthlyDeposit(double monthlyDeposit);
    void setAnnualInterestRate(double annualInterestRate);
    void setNumberOfYears(int numberOfYears);

    double getInitialInvestment();
    double getMonthlyDeposit();
    double getAnnualInterestRate();
    int getNumberOfYears();

    void calculateInvestmentGrowth();
    double calculateCompoundInterest(double openingAmount);
};

#endif /* INVESTMENT_CALCULATOR_H_ */